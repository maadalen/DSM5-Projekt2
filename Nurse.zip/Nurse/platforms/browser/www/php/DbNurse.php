
<?php 

require 'php/db.php';
session_start();

$username = $_GET['username']; 
$password = $_GET['password']; 
$result = $mysqli->query("' SELECT username , pw, role  FROM user_tab WHERE username = '$username' and pw = '$userid'");


if ( $result->num_rows == 0 ){ // User doesn't exist
    $_SESSION['message'] = "Username or password is wrong ";
   
}
else { // User exists
    $user = $result->fetch_assoc();
	print_r($user); die;
	$role = null;
    if ( password_verify($_POST['password'], $user['password']) ) {
        
        $_SESSION['username'] = $user['username'];
        $_SESSION['pw'] = $user['pw'];
		$_SESSION ['role'] = $user['role'];
        
        // This is how we'll know the user is logged in
        $_SESSION['logged_in'] = true;

        //header("location: profile.php");
    }
    else {
        $_SESSION['message'] = "You have entered wrong password, try again!";
       // header("location: error.php");
    }
 
?>
 